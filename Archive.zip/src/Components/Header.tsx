import {Link, Route, Routes } from 'react-router-dom'

type Props = {
    darkTheme: boolean,
    toggleDarkTheme: () => void
}

function Header({darkTheme, toggleDarkTheme}: Props) {
  return (
    <div className='header--container'>
        <Link to='/'> Stepan Orlov </Link>
        <div className='routes--container'>
            <Link to='/profile' className='routes--profile'> Profile </Link>
            <Link to='/projects' className='routes--projects'> Projects </Link>
            <button onClick={toggleDarkTheme} className='header--dark-theme'>{darkTheme ? "☀" : "☽"}</button>
            {/* <Link to='/blog' className='routes--blog'> Blog </Link> */}
        </div>
    </div>
  )
}

export default Header