import React from 'react'

function Profile() {
  return (
    <div>
        <p> 
                I have graduated from Spiced Academy Full Stack coding boot camp, so here's some stuff I am also familiar with:
             </p>
             <ul>
                <li>JavaScript (ES6), jQuery, Typescript, HTML5, CSS3</li>
                <li>Frontend: React, Redux, Vue.js, Angular, Figma</li>
                <li>Backend: Node.js, Express.js, Socket.IO</li>
                <li>Database: PostgreSQL</li>
                <li>Hosting: AWS (S3), Heroku</li>
                <li>Other: Wordpress, PHP</li>
             </ul>
    </div>
  )
}

export default Profile